'use strict';
// Tests for the front-end query engine (Boolean, wildcards, auto-expansion).
// The engine is extracted from public/index.html and run in a sandbox with a tiny dataset.
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const html = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
const block = html.slice(html.indexOf('/*QE-BEGIN*/'), html.indexOf('/*QE-END*/'));
const line = name => html.split('\n').find(l => l.startsWith('function ' + name + '('));
assert.ok(block.length > 1000, 'query engine markers not found');

// record: [cites, authors, title, year, sourceIdx, publisherIdx, placeIdx, countryIdx, url, doi, issn, keywords, abstract]
const REC = [
  [5, 'Smith J', 'Digital libraries and metadata', 2020, 0, 0, 0, 0, '', '10.1/a', '', 'metadata; digital libraries', 'About repositories'],
  [2, 'Lee K', 'Linked data for archives', 2021, 0, 0, 0, 0, '', '10.1/b', '', 'linked data', 'Survey of archives'],
  [9, 'Roy P', 'Bibliographic cataloguing practice', 2019, 0, 0, 0, 0, '', '10.1/c', '', 'cataloguing', 'Practice of cataloguing'],
  [1, 'Das A', 'Organization of knowledge', 2018, 0, 0, 0, 0, '', '10.1/d', '', 'knowledge organization; OPAC', 'Online public access catalog study'],
  [3, 'Sen B', 'Organisation of repositories survey', 2022, 0, 0, 0, 0, '', '10.1/e', '', 'repositories', 'A survey'],
];
const ctx = {
  console, R: REC, S: [''], PUB: [''], CO: [''],
  state: { query: '', expand: true },
  window: {},
  document: { getElementById: () => null },
  esc: s => String(s ?? ''),
};
vm.createContext(ctx);
vm.runInContext([line('norm'), line('exactPhrases')].join('\n'), ctx);
vm.runInContext(block, ctx);
vm.runInContext(`INDEX = R.map(r => ({ t: norm(r[2]), a: norm(r[1]), k: norm(r[11]), s: '', b: norm(r[12]), d: norm(r[9]), p: '', c: '' }));`, ctx);

const search = (q, expand = false) =>
  Array.from(vm.runInContext(`(function(q, e){ const o=[]; for (let i=0;i<R.length;i++){ const r=relevance(i,q,{expand:e}); const s=typeof r==='number'?r:r.score; if(s>0)o.push(i);} return o.sort(); })`, ctx)(q, expand));

test('plain queries still need every term (unchanged behaviour)', () => {
  assert.deepEqual(search('digital libraries'), [0]);
  assert.deepEqual(search('the metadata of libraries'), [0]);
});

test('lowercase and/or/not remain stop words', () => {
  assert.deepEqual(search('metadata or archives'), []);
  assert.deepEqual(search('digital and libraries'), [0]);
});

test('OR widens the result set', () => {
  assert.deepEqual(search('metadata OR "linked data"'), [0, 1]);
});

test('NOT and leading minus exclude records', () => {
  assert.deepEqual(search('repositories NOT survey'), [0]);
  assert.deepEqual(search('repositories -survey'), [0]);
  assert.deepEqual(search('NOT survey'), [0, 2, 3]);
});

test('brackets group terms', () => {
  assert.deepEqual(search('(metadata OR cataloguing) AND NOT digital'), [2]);
  assert.deepEqual(search('(metadata OR archives) survey'), [1]);
});

test('wildcards: right, left, both-sided and single character', () => {
  assert.deepEqual(search('catalog*'), [2, 3]);
  assert.deepEqual(search('*graphic'), [2]);
  assert.deepEqual(search('*log*'), [2, 3]);
  assert.deepEqual(search('organi?ation'), [3, 4]);
  assert.deepEqual(search('"digital lib*"'), [0]);
});

test('Boolean + wildcard combine', () => {
  assert.deepEqual(search('organi?ation NOT survey'), [3]);
});

test('auto-expansion adds records matched through variants and abbreviations', () => {
  ctx.window.lisSemExpand = ph => (ph === 'ko' ? [{ text: 'Knowledge Organization (KO)', kind: 'variant' }] : []);
  assert.deepEqual(search('ko', false), []);
  assert.deepEqual(search('ko', true), [3]);
  const c = vm.runInContext(`qCompile('ko', true)`, ctx);
  assert.ok(c.exps.some(e => e.text === 'knowledge organization'));
});

test('expansion does not change queries without a synonym match', () => {
  ctx.window.lisSemExpand = () => [];
  assert.deepEqual(search('digital libraries', true), [0]);
  assert.equal(vm.runInContext(`qCompile('digital libraries', true).classic`, ctx), true);
});

test('highlight marks wildcard matches', () => {
  ctx.state.expand = true;
  const out = vm.runInContext(`highlight('Organisation of data', 'organi?ation')`, ctx);
  assert.match(out, /<mark class="match">Organisation<\/mark>/);
});

test('built-in LIS thesaurus and spelling variants expand automatically', () => {
  ctx.window.lisSemExpand = () => [];
  const ex = q => Array.from(vm.runInContext(`qCompile(${JSON.stringify(q)}, true).exps.map(e => e.text)`, ctx));
  assert.ok(ex('opac').includes('online public access catalog'));
  assert.ok(ex('catalogue').includes('catalog'));
  assert.ok(ex('organisation').includes('organization'));
  assert.deepEqual(search('organisation', true), [3, 4]);
});

test('expanded terms do not match journal names, authors or DOIs', () => {
  ctx.window.lisSemExpand = () => [];
  const i = REC.length;
  REC.push([0, 'Someone', 'Unrelated title', 2020, 0, 0, 0, 0, '', '10.1/z', '', 'other', 'other']);
  vm.runInContext(`INDEX.push({ t: 'unrelated title', a: 'someone', k: 'other', s: 'scientometrics', b: 'other', d: '10.1/z', p: '', c: '' });`, ctx);
  ctx.window.lisSemExpand = ph => (ph === 'bibliometrics' ? [{ text: 'Scientometrics', kind: 'synonym' }] : []);
  assert.ok(!search('bibliometrics', true).includes(i));
});
